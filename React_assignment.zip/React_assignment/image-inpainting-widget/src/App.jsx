import React, { useState, useRef, useEffect } from "react";
import CanvasDraw from "react-canvas-draw";

function App() {
  const [image, setImage] = useState(null);
  const [brushSize, setBrushSize] = useState(5);
  const [maskImage, setMaskImage] = useState(null); // State to store the generated mask
  const canvasRef = useRef(null);

  // Handle image upload
  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setImage(imageUrl);
    }
  };

  // Export mask as an image
  const exportMask = () => {
    if (canvasRef.current) {
      const canvas = canvasRef.current.canvasContainer.children[1]; // Get the drawing layer
      const ctx = canvas.getContext("2d");

      // Create a new canvas to generate the mask image with black background
      const maskCanvas = document.createElement("canvas");
      const maskCtx = maskCanvas.getContext("2d");

      // Set canvas dimensions to match the drawing canvas
      maskCanvas.width = canvas.width;
      maskCanvas.height = canvas.height;

      // Fill the mask canvas with a black background
      maskCtx.fillStyle = "black";
      maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);

      // Draw the existing white mask (drawn area) from the original canvas onto the mask canvas
      maskCtx.drawImage(canvas, 0, 0);

      // Generate the mask image data
      const generatedMask = maskCanvas.toDataURL("image/png");
      setMaskImage(generatedMask); // Save the generated mask to state

      // Trigger the download of the mask image
      const link = document.createElement("a");
      link.href = generatedMask;
      link.download = "mask.png";
      link.click();
    }
  };

  // Clear the canvas
  const clearCanvas = () => {
    if (canvasRef.current) {
      canvasRef.current.clear();
      setMaskImage(null); // Clear the mask preview as well
    }
  };

  // Automatically update the mask image in real-time
  useEffect(() => {
    if (canvasRef.current) {
      const interval = setInterval(() => {
        const canvas = canvasRef.current.canvasContainer.children[1];
        if (canvas) {
          const updatedMask = canvas.toDataURL("image/png");
          setMaskImage(updatedMask);
        }
      }, 500); // Update every 500ms
      return () => clearInterval(interval);
    }
  }, []);

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Image Inpainting Tool</h1>

      {/* Image Upload Section */}
      <div style={styles.uploadContainer}>
        <input
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          style={styles.fileInput}
        />
      </div>

      {/* Canvas Section */}
      {image && (
        <div style={styles.canvasContainer}>
          <CanvasDraw
            ref={canvasRef}
            imgSrc={image}
            brushColor="white" // Brush color is set to white for the drawn area
            backgroundColor="black" // Canvas background is set to black
            brushRadius={brushSize}
            lazyRadius={0}
            canvasWidth={500}
            canvasHeight={500}
            style={styles.canvas}
            immediateLoading={false} // Prevent immediate loading from affecting opacity
          />
        </div>
      )}

      {/* Controls Section */}
      <div style={styles.controls}>
        <div style={styles.brushControl}>
          <label style={styles.label}>
            Brush Size:{" "}
            <span
              style={{
                ...styles.brushSize,
                color: brushSize === 1 ? "black" : "#3b82f6", // Set the brush size text color to black if it's 1px
              }}
            >
              {brushSize}px
            </span>
          </label>
          <input
            type="range"
            min="1"
            max="50"
            value={brushSize}
            onChange={(e) => setBrushSize(Number(e.target.value))}
            style={styles.slider}
          />
        </div>
        <div style={styles.buttonContainer}>
          <button onClick={clearCanvas} style={styles.button}>
            Clear Canvas
          </button>
          <button onClick={exportMask} style={styles.button}>
            Export Mask
          </button>
        </div>
      </div>

      {/* Display Images Side-by-Side */}
      <div style={styles.imagesContainer}>
        {image && (
          <div style={styles.imagePreview}>
            <h3 style={styles.imageTitle}>Original Image</h3>
            <img
              src={image}
              alt="Uploaded"
              style={styles.image}
            />
          </div>
        )}
        {maskImage && (
          <div style={styles.imagePreview}>
            <h3 style={styles.imageTitle}>Generated Mask</h3>
            <img
              src={maskImage}
              alt="Generated Mask"
              style={{
                ...styles.image,
                maxWidth: "100%",
                height: "auto",
                boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)", // Adding shadow for better contrast
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}

// Styles
const styles = {
  container: {
    textAlign: "center",
    padding: "20px",
    fontFamily: "'Roboto', sans-serif",
    backgroundColor: "#99B898", // Replacing the blue background with soft green
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: "3rem",
    color: "#000", // Set the title color to black
    marginBottom: "20px",
    fontWeight: "bold",
    textTransform: "uppercase",
    letterSpacing: "2px",
  },
  uploadContainer: {
    marginBottom: "30px",
  },
  fileInput: {
    fontSize: "1.1rem",
    padding: "12px 20px",
    borderRadius: "5px",
    border: "2px solid #3b82f6",
    backgroundColor: "#fff",
    cursor: "pointer",
    transition: "all 0.3s ease",
  },
  canvasContainer: {
    marginTop: "30px",
    display: "flex",
    justifyContent: "center",
    position: "relative",
  },
  canvas: {
    border: "3px solid #3b82f6",
    borderRadius: "12px",
    backgroundColor: "black", // Set canvas background to black
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
  },
  controls: {
    marginTop: "40px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "25px",
    width: "100%",
  },
  brushControl: {
    display: "flex",
    alignItems: "center",
    gap: "15px",
  },
  label: {
    fontSize: "1.2rem",
    fontWeight: "bold",
    color: "#000", // Set the label color to black
  },
  brushSize: {
    color: "#3b82f6",
  },
  slider: {
    width: "250px",
    accentColor: "#2A363B", // Set the slider accent color to #2A363B
    borderColor: "#2A363B", // Set slider border color to #2A363B
  },
  buttonContainer: {
    display: "flex",
    gap: "20px",
  },
  button: {
    padding: "12px 25px",
    fontSize: "1.1rem",
    color: "#fff",
    backgroundColor: "#2A363B", // Set background color to #2A363B
    border: "2px solid #2A363B", // Set border color to #2A363B
    borderRadius: "8px",
    cursor: "pointer",
    transition: "background-color 0.3s ease, transform 0.2s",
    boxShadow: "0 4px 10px rgba(42, 54, 59, 0.2)", // Shadow for the button
  },
  buttonHover: {
    backgroundColor: "#99B898", // Hover color set to the soft green color (#99B898)
  },
  imagesContainer: {
    marginTop: "40px",
    display: "flex",
    justifyContent: "center",
    gap: "30px",
    flexWrap: "wrap",
    width: "100%",
  },
  imagePreview: {
    textAlign: "center",
    maxWidth: "500px",
    width: "100%",
  },
  imageTitle: {
    fontSize: "1.4rem",
    marginBottom: "15px",
    color: "#000", // Set the heading color to black
    fontWeight: "bold",
  },
  image: {
    maxWidth: "100%",
    border: "3px solid #3b82f6",
    borderRadius: "10px",
    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)",
    transition: "transform 0.3s ease-in-out",
  },
};

export default App;
